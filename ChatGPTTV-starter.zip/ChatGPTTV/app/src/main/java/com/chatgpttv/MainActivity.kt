package com.chatgpttv

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var conversation: TextView
    private lateinit var input: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY

        val bg = Color.rgb(15, 17, 27)
        val panel = Color.rgb(29, 33, 49)
        val white = Color.WHITE
        val accent = Color.rgb(145, 115, 255)

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(56, 28, 56, 28)
            setBackgroundColor(bg)
        }

        val title = TextView(this).apply {
            text = "ChatGPT TV"
            textSize = 30f
            setTextColor(white)
            gravity = Gravity.CENTER
        }
        page.addView(title, match(WRAP_CONTENT))

        val subtitle = TextView(this).apply {
            text = "Твой ИИ-помощник для телевизора"
            textSize = 18f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
        }
        page.addView(subtitle, match(WRAP_CONTENT))

        conversation = TextView(this).apply {
            text = "Привет! Я ChatGPT TV.\n\nПодключение ИИ ещё не настроено. Следующий шаг — безопасно подключить API."
            textSize = 22f
            setTextColor(white)
            setPadding(28, 24, 28, 24)
            setBackgroundColor(panel)
            gravity = Gravity.CENTER_VERTICAL
        }
        val convoParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
        ).apply { topMargin = 28; bottomMargin = 20 }
        page.addView(conversation, convoParams)

        input = EditText(this).apply {
            hint = "Напиши сообщение…"
            textSize = 20f
            setTextColor(white)
            setHintTextColor(Color.LTGRAY)
            setSingleLine(true)
            setPadding(20, 12, 20, 12)
            setBackgroundColor(panel)
        }
        page.addView(input, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 64
        ))

        val send = Button(this).apply {
            text = "Отправить"
            textSize = 18f
            setTextColor(white)
            setBackgroundTintList(android.content.res.ColorStateList.valueOf(accent))
            isFocusable = true
            setOnClickListener {
                val message = input.text.toString().trim()
                if (message.isNotEmpty()) {
                    conversation.text = "Ты: $message\n\nChatGPT: API пока не подключён. Мы настроим безопасное соединение на следующем этапе."
                    input.text.clear()
                }
            }
        }
        page.addView(send, LinearLayout.LayoutParams(260, 64).apply { topMargin = 14 })

        setContentView(page)
        send.requestFocus()
    }

    private fun match(height: Int) = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, height
    )

    companion object { private const val WRAP_CONTENT = ViewGroup.LayoutParams.WRAP_CONTENT }
}
